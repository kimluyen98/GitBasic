<?php
	$path = get_template_directory_uri();
	$path = $path.'/Module/Home/person_1_0_0';
	if($check == 0){
		$css_inline .= "
			<style>
			.person_1_0_0 {
				padding: 30px 0
			}
			
			.person_1_0_0__info {
				display: flex;
				flex-wrap: wrap;
				position: relative
			}
			
			.person_1_0_0__pic {
				width: 50%
			}
			
			.person_1_0_0__pic img {
				width: 100%
			}
			
			.person_1_0_0__ct {
				width: 50%;
				padding-left: 50px;
				padding-top: 80px
			}
			
			.person_1_0_0__title {
				font-size: 28px;
				text-align: center;
				padding: 0;
				margin: 0 0 15px;
				line-height: 40px;
				text-transform: uppercase;
				color: #000
			}
			
			.person_1_0_0__line {
				width: 258px;
				margin: 15px auto 40px;
				position: relative;
				border-top: 1px solid #e4cc6b
			}
			
			.person_1_0_0__line::before {
				width: 160px;
				margin: 0 auto;
				border-top: 3px solid #e4cc6b;
				position: absolute;
				left: 50px;
				top: -2px;
				content: '';
			}
			
			.person_1_0_0__name {
				text-transform: uppercase;
				font-size: 16px;
				text-align: right;
				color: #000
			}
			
			.person_1_0_0__more {
				color: #09a2d4;
				text-decoration: underline;
				font-style: italic
			}
			
			.person_1_0_0__tabs1 {
				position: absolute;
				right: 0px;
				bottom: 0px;
				z-index: 2
			}
			
			.person_1_0_0__tabs1 img {
				opacity: 0.5
			}
			
			.person_1_0_0__tabs1 img.active {
				opacity: 1;
				border: 2px solid #DCAF47
			}
			
			.person_1_0_0 .owl-dots {
				display: none
			}
			
			@media (max-width: 1280px) and (max-width: 1280px) {
				.person_1_0_0 .owl-carousel img {
					width: 80%
				}
			}
			
			@media (max-width: 1280px) {
				.person_1_0_0__tabs1 {
					right: 40px
				}
			}
			
			@media (max-width: 1024px) {
				.person_1_0_0__ct {
					padding-left: 0px;
					padding-top: 0px
				}
			}
			
			@media (max-width: 812px) {
				.person_1_0_0__title {
					font-size: 18px
				}
				.person_1_0_0 .owl-carousel img {
					width: 100%
				}
				.person_1_0_0__tabs1 img {
					width: 60px
				}
			}
			
			@media (max-width: 414px) {
				.person_1_0_0__info {
					display: block
				}
				.person_1_0_0__pic {
					width: 100%
				}
				.person_1_0_0__ct {
					width: 100%
				}
				.person_1_0_0__tabs1 {
					position: relative;
					right: auto;
					left: auto;
					margin-left: 30px;
					padding-top: 30px
				}
			}
			
			@media (max-width: 375px) {
				.person_1_0_0__tabs1 {
					margin-left: 40px
				}
				.person_1_0_0__tabs1 img {
					width: 45px
				}
			}
			
			@media (max-width: 320px) {
				.person_1_0_0__title {
					font-size: 15px;
					margin: 20px 0 0
				}
				.person_1_0_0__line {
					margin: 5px 0 20px
				}
				.person_1_0_0__tabs1 {
					margin-left: 20px
				}
			}
			</style>
		";
		add_action('wp_footer', 'person_1_0_0');
		function person_1_0_0(){
			echo '
				<script>
				$(".person_1_0_0 .owl-carousel").owlCarousel({loop:!1,margin:10,items:1,responsive:{0:{items:1},414:{items:1},768:{items:1},1024:{items:1},1280:{items:1}}});$(".tabs2 .tab").click((function(event){var selectedClass="active";$(".tabs2 .tab,.tabs2 .tab img").removeClass("active"),$(event.target).addClass("active")}));
				</script>
			';        
		
		};
	}
?>
  <section class="person_1_0_0">
        <div class="container">
            <div class="owl-carousel owl-theme">
              
				<?php
					foreach($field['person_info'] as $key => $value):
						$data = explode("\n",  $value["title"]);
						echo'
							<div class="person_1_0_0__info" data-hash="p'.$key.'">
							<div class="person_1_0_0__pic">
								<a href=""> <img src="'.$data[0].'" alt=""> </a>
							</div>
							<div class="person_1_0_0__ct">
								<div class="person_1_0_0__title">'.$field['person_title'].'</div>
								<div class="person_1_0_0__line"></div>
								<div class="person_1_0_0__desc">
									<p>'.$data[1].'
										<a href="'.$data[2].'" class="person_1_0_0__more">Xem thêm <i class="icon-angle-double-right"></i></a>
									</p>
								</div>
								<div class="person_1_0_0__name">- '.$data[3].' -</div>
							</div>
						</div>
						';
					endforeach;
				?>
            </div>
            <div class="person_1_0_0__tabs1 tabs2">
				<?php
					foreach($field['person_info'] as $key => $value):
						$data = explode("\n",  $value["title"]);
						echo'
						
						<a href="#p'.$key.'">
							<img src="'.$data[4].'" alt="'.$data[3].'" class=" tab active">
						</a>
						';
					endforeach;
				?>
            </div>
        </div>
    </section>


