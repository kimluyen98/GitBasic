<?php

/*FOOTER 3.0.0*/
'id_footer_3_0_0' => array(
    'key' => 'id_footer_3_0_0',
    'name' => 'footer_3_0_0',
    'label' => 'Footer 3.0.0',
    'display' => 'block',
    'sub_fields' => array(
        /* Code */
        array(
            'key' => 'id_footer_3_0_0_sub',
            'label' => 'Thông Tin',
            'name' => 'info',
            'type' => 'textarea',
            'instructions' => '',
            'required' => 0,
            'conditional_logic' => 0,
            'wrapper' => array(
                'width' => '',
                'class' => '',
                'id' => '',
            ),
            'default_value' => '',
            'placeholder' => '',
            'maxlength' => '',
            'rows' => 4,
            'new_lines' => '',
        ),
        /* End Code */
    ),
    'min' => '',
    'max' => '',
),
/*END FOOTER 3.0.0*/

?>